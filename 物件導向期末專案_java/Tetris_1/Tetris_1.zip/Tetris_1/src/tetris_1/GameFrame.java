/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetris_1;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.KeyAdapter;   
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * @author user
 */

 public class GameFrame extends JFrame {
	
    public GameFrame() {
        this.setTitle("Tetris");//設定標題
        this.setSize(700, 550);//設定尺寸
        this.setLayout(new BorderLayout());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//點選關閉按鈕是關閉程式
        this.setLocationRelativeTo(null);   //設定視窗顯示居中           
        this.setResizable(false); //不允許修改介面大小
        PanelGame game1=new PanelGame();
        this.setContentPane( game1);    //把PanelGame()設定成為frame的內容面板
        this.setVisible(true);
    }
}   

//class MyKeyListener extends KeyAdapter{
//public void keyPressed(KeyEvent e){
//char charA=e.getKeyChar();
//System.out.println("你按了《"+charA+"》鍵");
//}
//}
     

