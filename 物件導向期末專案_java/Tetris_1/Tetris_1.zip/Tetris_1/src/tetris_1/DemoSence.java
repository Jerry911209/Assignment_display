/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetris_1;

import java.awt.Graphics;
import javax.swing.JPanel;

/**
 *
 * @author Cai
 */
public class DemoSence{
    public void paintComponent(Graphics g){
    
}}
