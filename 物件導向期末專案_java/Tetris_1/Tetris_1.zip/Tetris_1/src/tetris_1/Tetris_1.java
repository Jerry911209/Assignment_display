/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tetris_1;

import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

/**
 *
 * @author user
 */
public class Tetris_1 {

    /**
     * @param args the command line arguments
     */
//    private static PanelGame gamepanel ;
    
    public static void main(String[] args) {
        
        final GameFrame game=new GameFrame();
        final PanelGame gamedraw=new PanelGame();
//        public void timer(){
            Timer time=new Timer();
        //在特定 delay 後重複執行
        time.schedule(new TimerTask(){
            public void run() {
               game.repaint();              
               System.out.println("period=800");
            }
        },1000,100);    //period -> 速率
//        }
    }
}
   

