/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tetris_1;

//import static com.sun.java.accessibility.util.AWTEventMonitor.addKeyListener;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JPanel;

/**
 *
 * @author user
 */
public class PanelGame extends JPanel  implements KeyListener{
    
//    int x=400,y=0,change=0,paint=0;
    int x=200,y=0,change=0,paint=0;
    int now_x_Index=0,now_y_Index=0;
    int block_bottomline = 0;   //方塊底邊高度
    int bg_block[][]=new int [20][15];  //背景格子
    int block[][]=new int[4][4];
    int rand=(int)(Math.random()*7);
//    int rand=6;   //測試用
    block b=new block();           
         
    
    
   
    public void move(){
        change ++;
        repaint();
    }
    
    @Override
    public void paintComponent(Graphics g)
    {
        switch(rand)
        {
            case 0:
                block=b.Iblock;
                break;
            case 1:
                block=b.Jblock;
                break;
            case 2:
                block=b.Lblock;
                break;
            case 3:
                block=b.Tblock;
                break;
            case 4:
                block=b.xblock;
                break;
            case 5:
                block=b.xzblock;
                break;
            case 6:
                block=b.zblock;
                break;
        }
        
        //繪製外框線
        g.drawLine(180, 0, 180, 440);   //left line
        g.drawLine(520, 0, 520, 440);   //right line
        g.drawLine(180, 440, 520, 440);   //bottom line
        g.drawLine(180, 0, 520, 0);   //top line

        //繪製背景格子
        int x1=200,y1=20;
        for(int i=0;i<20;i++)
        {
            for(int j=0;j<15;j++)
            {
                g.drawRect(x1,y1,20,20); //繪製矩形
                x1=x1+20;
            }
            y1=y1+20;
            x1=200;
        }
        
        //繪製方塊
        for(int i=0;i<16;i++)
        {     
            if(i % 4 == 0)  
            {
                y = y + 20; //移動至下一列
                x = 200;  //x恢復預設值
            }
            
//            if(block[change][12]==0&&block[change][13]==0&&block[change][14]==0&&block[change][15]==0)
//            {
//                if(i==11)
//                {
//                    break;
//                }
//            }
           

            if(block[change][i] == 1){
                
                
                
                g.setColor(Color.red);  //設定方塊顏色
                g.fillRect(x,y,20, 20); //繪製實心方塊
//                    g.setColor(Color.black);   //設定方塊邊線顏色
//                    g.drawRect(x,y,20,20);   //繪製空心方框
                block_bottomline = y;  //紀錄方塊bottomline的高度
                System.out.println("block_bottomline=" + block_bottomline);
////                
//                now_y_Index = (y-20)/20;
//                now_x_Index = (x-200)/20;
//
            }
            x=x+20; //右移一格

        }    
         //繪製新方塊
//        if(block_bottomline == 400 || bg_block[now_y_Index][now_x_Index]==0){
        if(block_bottomline == 400 ){
            System.out.println("next");
            rand=(int)(Math.random()*7);    //隨機樣式
            y=0;    //高度重置
        }
        else{
            y -= 60;  //將y設定為向下掉落一格的位置
        }
     //timemove();   
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e){
        switch(e.getKeyCode()){
            case KeyEvent.VK_DOWN: ;break;
            case KeyEvent.VK_UP: move();break;
            case KeyEvent.VK_LEFT: ; break;
            case KeyEvent.VK_RIGHT: ; break;
//            default: change = e.getKeyChar();
        }
        System.out.println("repaint");
        repaint();    
    }

}

